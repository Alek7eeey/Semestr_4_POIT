export default interface IState{
    category: string;
    price: string;
    stocked: boolean;
    name: string;
}
import IState from "../../IState";

export default interface IFilterable
{
    products: IState[];
}
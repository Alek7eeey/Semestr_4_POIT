import IState from "../../IState";

export default interface IProductRow
{
    product: IState
} 
export default interface IProductCategory
{
    category:string;
}
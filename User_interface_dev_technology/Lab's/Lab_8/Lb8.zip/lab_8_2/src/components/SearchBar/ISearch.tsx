export default interface ISearch{
    filterText:string;
    inStockOnly:boolean;
    onFilterTextChange:any;
    onInStockChange:any;
}